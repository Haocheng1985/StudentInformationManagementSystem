﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;

namespace TriStu.DAL
{
    public class DBHelper
    {
        public static string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\look\Desktop\db\StuDB.mdf;Integrated Security=True;Connect Timeout=30";

        public static SqlConnection conn = new SqlConnection(connString);

        #region get data
       
        public static DataTable GetDataTable(string sqlStr)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sqlStr, conn);
                SqlDataAdapter dapt = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dapt.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                return null;
                //throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        #endregion
        #region get data overload method
        
        public static DataTable GetDataTable(string sqlStr, SqlParameter[] param)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sqlStr, conn);
                cmd.Parameters.AddRange(param);
                SqlDataAdapter dapt = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                dapt.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                return null;
                //throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        #endregion
        #region update
       
        public static bool ExcuteCommand(string sqlStr)
        {
            try
            {
                //conn.Open();
                SqlCommand cmd = new SqlCommand(sqlStr, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                //throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        #endregion
        #region update overload
       
        public static bool ExcuteCommand(string sqlStr, SqlParameter[] param)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sqlStr, conn);
                cmd.Parameters.AddRange(param);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                //throw ex;
            }
            finally
            {
                conn.Close();
            }
        }
        #endregion

        public static bool ExcuteCommand(List<String> sqlStr, List<SqlParameter[]> param)
        {
            int i = 0;
            SqlCommand cmd = new SqlCommand();
            using (TransactionScope ts = new TransactionScope())
            {
                cmd.Connection = conn;
                conn.Open();
                try
                {
                    foreach (string item in sqlStr)
                    {
                        
                        cmd.CommandType = CommandType.Text;
                        
                        cmd.CommandText = item;
                        
                        cmd.Parameters.AddRange(param[i]);
                        
                        cmd.ExecuteNonQuery();
                        i++;
                    }
                    ts.Complete();
                    return true;
                }
                catch (Exception ex)
                {
                    throw ex;
                    return false;
                }
                finally
                {
                    conn.Close();
                    sqlStr.Clear();
                }
            }
        }




    }
}
