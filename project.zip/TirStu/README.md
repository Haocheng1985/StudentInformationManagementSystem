# StudentInformationManagementSystem

The functions included in this application are displaying, adding, editing and deleting students’ information. This application uses MVC Architecture. Database is the data source.
